
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.infection.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.RegisterColorHandlersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.block.Block;

import net.mcreator.infection.block.WeinerBlock;
import net.mcreator.infection.block.LianiBlock;
import net.mcreator.infection.block.InfectedplanksBlock;
import net.mcreator.infection.block.InfectedgrassBlock;
import net.mcreator.infection.block.Infected4LogBlock;
import net.mcreator.infection.block.GooeyBlock;
import net.mcreator.infection.block.CorrograssBlock;
import net.mcreator.infection.block.CorrodirtBlock;
import net.mcreator.infection.InfectionMod;

public class InfectionModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, InfectionMod.MODID);
	public static final RegistryObject<Block> INFECTEDGRASS = REGISTRY.register("infectedgrass", () -> new InfectedgrassBlock());
	public static final RegistryObject<Block> INFECTED_GRASS = REGISTRY.register("infected_grass", () -> new GooeyBlock());
	public static final RegistryObject<Block> INFECTED_DIRT = REGISTRY.register("infected_dirt", () -> new WeinerBlock());
	public static final RegistryObject<Block> CORRODIRT = REGISTRY.register("corrodirt", () -> new CorrodirtBlock());
	public static final RegistryObject<Block> CORROGRASS = REGISTRY.register("corrograss", () -> new CorrograssBlock());
	public static final RegistryObject<Block> LIANI = REGISTRY.register("liani", () -> new LianiBlock());
	public static final RegistryObject<Block> INFECTEDPLANKS = REGISTRY.register("infectedplanks", () -> new InfectedplanksBlock());
	public static final RegistryObject<Block> INFECTED_4_LOG = REGISTRY.register("infected_4_log", () -> new Infected4LogBlock());

	// Start of user code block custom blocks
	// End of user code block custom blocks
	@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class BlocksClientSideHandler {
		@SubscribeEvent
		public static void blockColorLoad(RegisterColorHandlersEvent.Block event) {
			InfectedgrassBlock.blockColorLoad(event);
		}

		@SubscribeEvent
		public static void itemColorLoad(RegisterColorHandlersEvent.Item event) {
			InfectedgrassBlock.itemColorLoad(event);
		}
	}
}
