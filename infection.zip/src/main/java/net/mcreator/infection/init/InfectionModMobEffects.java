
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.infection.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.effect.MobEffect;

import net.mcreator.infection.potion.TheInfectionMobEffect;
import net.mcreator.infection.InfectionMod;

public class InfectionModMobEffects {
	public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, InfectionMod.MODID);
	public static final RegistryObject<MobEffect> THE_INFECTION = REGISTRY.register("the_infection", () -> new TheInfectionMobEffect());
}
