
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.infection.init;

import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.infection.InfectionMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class InfectionModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, InfectionMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(InfectionModItems.THECUMLUNCHLY.get());
			tabData.accept(InfectionModItems.CORRUPTSWORD.get());
			tabData.accept(InfectionModItems.CORRUPTSHOVEL.get());
			tabData.accept(InfectionModItems.CORRUPTHOE.get());
			tabData.accept(InfectionModItems.CORRUPTAXE.get());
		}
	}
}
