
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.infection.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.infection.item.ThecumlunchlyItem;
import net.mcreator.infection.item.InfectedsticksItem;
import net.mcreator.infection.item.InfecteddildoItem;
import net.mcreator.infection.item.CorruptswordItem;
import net.mcreator.infection.item.CorruptshovelItem;
import net.mcreator.infection.item.CorrupthoeItem;
import net.mcreator.infection.item.CorruptaxeItem;
import net.mcreator.infection.InfectionMod;

public class InfectionModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, InfectionMod.MODID);
	public static final RegistryObject<Item> INFECTEDGRASS = block(InfectionModBlocks.INFECTEDGRASS);
	public static final RegistryObject<Item> INFECTED_GRASS = block(InfectionModBlocks.INFECTED_GRASS);
	public static final RegistryObject<Item> INFECTED_DIRT = block(InfectionModBlocks.INFECTED_DIRT);
	public static final RegistryObject<Item> CORRODIRT = block(InfectionModBlocks.CORRODIRT);
	public static final RegistryObject<Item> CORROGRASS = block(InfectionModBlocks.CORROGRASS);
	public static final RegistryObject<Item> THECUMLUNCHLY = REGISTRY.register("thecumlunchly", () -> new ThecumlunchlyItem());
	public static final RegistryObject<Item> CORRUPTSWORD = REGISTRY.register("corruptsword", () -> new CorruptswordItem());
	public static final RegistryObject<Item> CORRUPTSHOVEL = REGISTRY.register("corruptshovel", () -> new CorruptshovelItem());
	public static final RegistryObject<Item> CORRUPTHOE = REGISTRY.register("corrupthoe", () -> new CorrupthoeItem());
	public static final RegistryObject<Item> CORRUPTAXE = REGISTRY.register("corruptaxe", () -> new CorruptaxeItem());
	public static final RegistryObject<Item> LIANI = block(InfectionModBlocks.LIANI);
	public static final RegistryObject<Item> INFECTEDPLANKS = block(InfectionModBlocks.INFECTEDPLANKS);
	public static final RegistryObject<Item> INFECTED_4_LOG = block(InfectionModBlocks.INFECTED_4_LOG);
	public static final RegistryObject<Item> INFECTEDSTICKS = REGISTRY.register("infectedsticks", () -> new InfectedsticksItem());
	public static final RegistryObject<Item> INFECTEDDILDO = REGISTRY.register("infecteddildo", () -> new InfecteddildoItem());

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
