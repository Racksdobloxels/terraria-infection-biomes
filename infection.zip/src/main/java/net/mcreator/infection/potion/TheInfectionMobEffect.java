
package net.mcreator.infection.potion;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;

import java.util.List;
import java.util.ArrayList;

public class TheInfectionMobEffect extends MobEffect {
	public TheInfectionMobEffect() {
		super(MobEffectCategory.HARMFUL, -13434880);
		this.addAttributeModifier(Attributes.MAX_HEALTH, "23ebcf53-877f-3b30-8535-29b65aebabd0", -1, AttributeModifier.Operation.ADDITION);
	}

	@Override
	public boolean isInstantenous() {
		return true;
	}

	@Override
	public List<ItemStack> getCurativeItems() {
		ArrayList<ItemStack> cures = new ArrayList<ItemStack>();
		return cures;
	}

	@Override
	public boolean isDurationEffectTick(int duration, int amplifier) {
		return true;
	}
}
